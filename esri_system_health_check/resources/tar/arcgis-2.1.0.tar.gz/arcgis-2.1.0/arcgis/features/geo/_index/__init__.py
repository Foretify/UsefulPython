from ._impl import SpatialIndex
