"""
Graphing Library
"""
from arcgis.features.geo._viz.mapping import plot

__all__ = ["plot"]
